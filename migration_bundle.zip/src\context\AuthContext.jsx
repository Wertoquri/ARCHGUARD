import React from 'react';

// Minimal AuthContext stub for test environment and migrations.
const AuthContext = React.createContext(null);

export default AuthContext;
